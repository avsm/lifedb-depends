(* $Id: netcgi1_compat.ml 1003 2006-09-24 15:17:15Z gerd $ *)

module Netcgi_env = Netcgi_env

module Netcgi_types = Netcgi_types

module Netcgi = Netcgi
