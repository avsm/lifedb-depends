/* What one can expect from any POSIX system: */

#define HAVE__EXIT
#define HAVE_SYSCONF
#define HAVE_GETPGID
#define HAVE_SETPGID
#define HAVE_TCGETPGRP
#define HAVE_TCSETPGRP
#define HAVE_CTERMID
#define HAVE_TTYNAME
#define HAVE_GETSID
#define HAVE_SETREUID
#define HAVE_SETREGID
