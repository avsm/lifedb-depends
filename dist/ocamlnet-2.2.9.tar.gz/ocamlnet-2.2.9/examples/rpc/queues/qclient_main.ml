(* $Id: qclient_main.ml 874 2006-05-04 14:07:27Z gerd $ *)

(* Rpc_client.verbose true; *)
Qclient.main() ;;
